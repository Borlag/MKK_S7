# SpecSorter v4.3 (Modular)
- GUI: `python -m specsorter.cli gui`
- CLI: `python -m specsorter.cli -c resources/config.yaml sort|catalog|audit`
Depends: `openpyxl`, `pyyaml` (+ `pywin32` for Windows shortcuts).
