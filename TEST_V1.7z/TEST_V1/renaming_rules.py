"""
Движок правил распознавания и форматирования имен.

Цели:
- Надёжное распознавание семейства (папки назначения).
- Нормализация ОС-имени (fs_name) строго по правилам коллеги.
- Отдельная нормализация "display name" для Excel (например, AMSXXXX_X -> AMSXXXX/X).

Ключевые семейства с особыми правилами до наполнения библиотеки:
DAN, DIN, HST, ISO, LN, MEP, MS, NAS, NE, TAN, AIPI, AN, ARP, AMS (+QPL), D8, D6, D2.
"""

import re
import yaml
from typing import Any, Dict, List, Optional, Tuple
from pathlib import Path

class FileNameFormatter:
    """
    Форматирование имени файла.

    Правила:
    - format_fs_name(): имя ОС-файла (всегда с расширением).
    - format_display_name(): заголовок для Excel (может отличаться, напр. AMSxxxx_x -> AMSxxxx/x).
    """

    # Служебные множества/константы
    ABBREVS_WITH_SPACE = {'MEP', 'NE', 'SPM', 'TAN'}  # MEP XX-XXX; NE XX-XXX; ...
    ABBREVS_WITHOUT_SPACE = {
        'AIPI','AN','ARP','BAC','BACB','BACC','BACD','BACF','BACI','BACJ',
        'BACL','BACN','BACP','BACR','BACS','BACT','BACV','BACW',
        'DAN','LN','MS','NAS','HST'
    }

    ABBREVS_TO_UPPERCASE = {
        'HST','MS','NAS','СП','MIL','ASTM','QQ','LN',
        'BAC','BACB','BACC','BACD','BACF','BACI','BACJ',
        'BACL','BACN','BACP','BACR','BACS','BACT','BACV','BACW'
    }

    ACRONYMS_TREATED_AS_BASE = {'AMS', 'ASTM', 'ASME', 'FED', 'MIL', 'QQ', 'TN', 'ASD', 'AWS', 'PDS'}
    DIN_COMPOUND = ('EN', 'ISO', 'SAE', 'SPEC')

    def _split(self, basename: str) -> Tuple[str, str]:
        p = Path(basename)
        return p.stem, p.suffix  # suffix включает точку или пусто

    def _squash_spaces(self, s: str) -> str:
        return re.sub(r'\s+', ' ', s).strip()

    # ------ Публичные методы ------

    def format_fs_name(self, basename: str, folder: str, original_abbrev: str) -> str:
        """
        Вернуть нормализованное имя ОС-файла с расширением.
        """
        stem, ext = self._split(basename)
        ext = ext or ""  # важная страховка сохранения исходного расширения
        folder_up = folder.upper()
        orig_up = original_abbrev.upper()
        name = stem

        # Убираем префикс "SAE " при наличии (единое поведение для SAE AMS/ISO SAE ...)
        name = re.sub(r'^(?i:SAE)[\s_-]*', '', name).strip()

        # --- Базовые нормализации по семействам ---

        # AIPI / AN / ARP: без пробела после префикса
        if folder_up in ('AIPI', 'AN', 'ARP'):
            name = re.sub(rf'^(?i:{folder_up})\s+', folder_up, name)

        # BAC, DAN, LN, MS, NAS, HST: без пробела
        if folder_up in self.ABBREVS_WITHOUT_SPACE:
            name = re.sub(rf'^(?i:{folder_up})[\s_-]+', folder_up, name)

        # MEP/NE/SPM/TAN: обязательный пробел
        if folder_up in self.ABBREVS_WITH_SPACE:
            name = re.sub(rf'^(?i:{folder_up})[\s_-]*', f'{folder_up} ', name)

        # DIN-комбинации
        if folder_up == 'DIN':
            # DIN EN/ISO/SAE(SPEC) ...
            if re.match(r'^(?i:DIN)\s*(?:_|-|\s)*EN', name):
                name = re.sub(r'^(?i:DIN)\s*(?:_|-|\s)*EN', 'DIN EN', name).strip()
            elif re.match(r'^(?i:DIN)\s*(?:_|-|\s)*ISO', name):
                name = re.sub(r'^(?i:DIN)\s*(?:_|-|\s)*ISO', 'DIN ISO', name).strip()
            elif re.match(r'^(?i:DIN)\s*(?:_|-|\s)*SAE(?:\s*(?:_|-|\s)*SPEC)?', name):
                # DIN SAE [SPEC]
                name = re.sub(r'^(?i:DIN)\s*(?:_|-|\s)*SAE(\s*(?:_|-|\s)*SPEC)?', r'DIN SAE\1', name).strip()
            else:
                # DIN <цифры>
                name = re.sub(r'^(?i:DIN)[\s_-]+', 'DIN ', name).strip()

       # ISO комбинации
        if folder_up == 'ISO':
            # Вариант ISO SAE (PAS)
            if re.match(r'^ISO\s*(?:_|-|\.)*\s*SAE(?:\s*(?:_|-|\.)*\s*PAS)?', name, flags=re.IGNORECASE):
                tail = re.sub(r'^ISO\s*(?:_|-|\.)*\s*SAE(?:\s*(?:_|-|\.)*\s*PAS)?', '', name, flags=re.IGNORECASE).lstrip(' _-.')
                if re.match(r'^(?i:PAS)\b', tail):
                    tail = re.sub(r'^(?i:PAS)\s*', '', tail).lstrip(' _-.')
                    name = f"ISO PAS {tail}".strip()
                else:
                    name = f"ISO {tail}".strip()
            # Вариант ISO IEC
            elif re.match(r'^ISO\s*(?:_|-|\.)*\s*IEC', name, flags=re.IGNORECASE):
                tail = re.sub(r'^ISO\s*(?:_|-|\.)*\s*IEC', '', name, flags=re.IGNORECASE).lstrip(' _-.')
                name = f"ISO IEC {tail}".strip()
            else:
                # Простой ISO: приводим префикс к "ISO ":
                # 1) ISO[разделители]+X -> ISO X
                name = re.sub(r'^ISO(?:\s*|_|-|\.)+', 'ISO ', name, flags=re.IGNORECASE)
                # 2) ISO<цифра> -> ISO <цифра>
                name = re.sub(r'^ISO(?=\d)', 'ISO ', name, flags=re.IGNORECASE)


        # ASTM — дефис после ASTM-
        if folder_up == 'ASTM':
            if not re.match(r'^(?i:ASTM)-', name):
                name = re.sub(r'^(?i:ASTM)([A-Z])', r'ASTM-\1', name)

        # MIL — MIL-STD/-PRF/-DTL/-HDBK/-SPEC
        if folder_up == 'MIL':
            m = re.match(r'^(?i:MIL)([A-Z]+)', name)
            if m:
                suffix = m.group(1).upper()
                if suffix in ['STD', 'PRF', 'DTL', 'HDBK', 'SPEC']:
                    name = re.sub(r'^(?i:MIL)'+suffix, f'MIL-{suffix}', name)

        # PPP — правка PPP-H-
        if folder_up == 'PPP':
            name = re.sub(r'^(?i:PPPH)-', 'PPP-H-', name)

        # AMS — убрать пробелы после AMS, добавить дефис для AMS-STD/PRF/...; нижние подчёркивания оставляем
        if folder_up == 'AMS':
            name = re.sub(r'^(?i:AMS)\s+', 'AMS', name)
            m = re.match(r'^(?i:AMS)([A-Z]+)', name)
            if m:
                suffix = m.group(1).upper()
                name = re.sub(r'^(?i:AMS)'+suffix, f'AMS-{suffix}', name)

        # --- QPL: особая логика ---
        if orig_up == 'QPL':
            # Попытка вычислить целевой стандарт только если после QPL реально стоит аббревиатура
            original_name = name
            cleaned = re.sub(r'^(?i:QPL)(?:[\s_-]*to)?[\s_-]*', '', name).strip()
            # Считаем целевыми: AMS/BMS/MIL/ASTM/BAC(B/C/...)/NAS/MS/LN/ISO/DIN/ASME/FED/QQ/TN/ASD/AWS/PDS
            if re.match(r'^(?i:(AMS|BMS|MIL|ASTM|BAC[A-Z]?|NAS|MS|LN|ISO|DIN|ASME|FED|QQ|TN|ASD|AWS|PDS))\b', cleaned):
                # есть целевой — используем cleaned
                name = cleaned
                # Добавляем .QPL только если ещё не был добавлен
                if not name.upper().endswith('.QPL'):
                    return f"{name}.QPL{ext}"
                else:
                    return f"{name}{ext}"
            else:
                # целевой не распознан — оставляем как было (включая 'QPL ...'), НИЧЕГО не добавляем
                name = original_name
                # не плодить дубли .QPL
                if name.upper().endswith('.QPL'):
                    return f"{name}{ext}"
                return f"{name}{ext}"

        # Гарантируем верхний регистр ряда префиксов
        for pref in self.ABBREVS_TO_UPPERCASE:
            name = re.sub(rf'^(?i:{pref})', pref, name)

        name = self._squash_spaces(name)
        return name + ext

    def format_display_name(self, fs_basename: str, folder: str, original_abbrev: str) -> str:
        """
        Представление для Excel (без обязательства совпадать с OS-именем).
        Примеры:
        - AMSXXXX_X -> AMSXXXX/X
        - AMS-QQ-P-416_5 -> AMS-QQ-P-416/5
        """
        stem, _ext = self._split(fs_basename)
        if folder.upper() == 'AMS':
            if '_' in stem:
                parts = stem.split('_')
                if len(parts[-1]) <= 2:
                    return '/'.join(['_'.join(parts[:-1]), parts[-1]])
        return stem


class RulesEngine:
    """
    Движок распознавания семейства по имени файла (регулярки + пост-валидация).
    """

    def __init__(self, rules_file: Optional[str] = None, logger=None):
        self.logger = logger
        self.detect_rules: List[Dict[str, Any]] = []
        self._load_yaml_rules(rules_file)

    DEFAULT_RULES_YAML = """
detect:
  # QPL to TARGET
  - name: QPL
    priority: 300
    pattern: '^(?:QPL)(?:[\\s_-]*to)?[\\s_-]*([A-Z]{2,4})[\\s_-]*(.+)$'
    folder_from_group: 1
    original_abbrev: 'QPL'

  # BAC* subfamilies (должны идти раньше общего BAC!)
  - name: BACB
    priority: 189
    pattern: '^BACB[\\s\\-A-Z0-9_]+'
    folder: 'BACB'
    original_abbrev: 'BACB'
  - name: BACC
    priority: 189
    pattern: '^BACC[\\s\\-A-Z0-9_]+'
    folder: 'BACC'
    original_abbrev: 'BACC'
  - name: BACD
    priority: 189
    pattern: '^BACD[\\s\\-A-Z0-9_]+'
    folder: 'BACD'
    original_abbrev: 'BACD'
  - name: BACF
    priority: 189
    pattern: '^BACF[\\s\\-A-Z0-9_]+'
    folder: 'BACF'
    original_abbrev: 'BACF'
  - name: BACI
    priority: 189
    pattern: '^BACI[\\s\\-A-Z0-9_]+'
    folder: 'BACI'
    original_abbrev: 'BACI'
  - name: BACJ
    priority: 189
    pattern: '^BACJ[\\s\\-A-Z0-9_]+'
    folder: 'BACJ'
    original_abbrev: 'BACJ'
  - name: BACL
    priority: 189
    pattern: '^BACL[\\s\\-A-Z0-9_]+'
    folder: 'BACL'
    original_abbrev: 'BACL'
  - name: BACN
    priority: 189
    pattern: '^BACN[\\s\\-A-Z0-9_]+'
    folder: 'BACN'
    original_abbrev: 'BACN'
  - name: BACP
    priority: 189
    pattern: '^BACP[\\s\\-A-Z0-9_]+'
    folder: 'BACP'
    original_abbrev: 'BACP'
  - name: BACR
    priority: 189
    pattern: '^BACR[\\s\\-A-Z0-9_]+'
    folder: 'BACR'
    original_abbrev: 'BACR'
  - name: BACS
    priority: 189
    pattern: '^BACS[\\s\\-A-Z0-9_]+'
    folder: 'BACS'
    original_abbrev: 'BACS'
  - name: BACT
    priority: 189
    pattern: '^BACT[\\s\\-A-Z0-9_]+'
    folder: 'BACT'
    original_abbrev: 'BACT'
  - name: BACV
    priority: 189
    pattern: '^BACV[\\s\\-A-Z0-9_]+'
    folder: 'BACV'
    original_abbrev: 'BACV'
  - name: BACW
    priority: 189
    pattern: '^BACW[\\s\\-A-Z0-9_]+'
    folder: 'BACW'
    original_abbrev: 'BACW'

  # AIPI (без пробела)
  - name: AIPI
    priority: 190
    pattern: '^AIPI\\s*\\d'
    folder: 'AIPI'
    original_abbrev: 'AIPI'

  # AN / ARP — без пробела
  - name: AN
    priority: 188
    pattern: '^AN\\s*\\d'
    folder: 'AN'
    original_abbrev: 'AN'
  - name: ARP
    priority: 188
    pattern: '^ARP\\s*\\d'
    folder: 'ARP'
    original_abbrev: 'ARP'

  # AMS (все формы)
  - name: AMS
    priority: 180
    pattern: '^(?:SAE[\\s_-]*)?AMS[-\\sA-Z0-9_]+'
    folder: 'AMS'
    original_abbrev: 'AMS'

  # D8 / D6 / D2 (только с дефисом)
  - name: D8
    priority: 170
    pattern: '^D8-\\w+'
    folder: 'D8'
    original_abbrev: 'D8'
  - name: D6
    priority: 170
    pattern: '^D6-\\w+'
    folder: 'D6'
    original_abbrev: 'D6'
  - name: D2
    priority: 170
    pattern: '^D2-\\w+'
    folder: 'D2'
    original_abbrev: 'D2'

  # DIN combos
  - name: DIN EN ISO
    priority: 160
    pattern: '^DIN(?:\\s*|_|-)*EN(?:\\s*|_|-)*ISO'
    folder: 'DIN'
    original_abbrev: 'DIN EN ISO'
  - name: DIN EN
    priority: 150
    pattern: '^DIN(?:\\s*|_|-)*EN'
    folder: 'DIN'
    original_abbrev: 'DIN EN'
  - name: DIN ISO
    priority: 150
    pattern: '^DIN(?:\\s*|_|-)*ISO'
    folder: 'DIN'
    original_abbrev: 'DIN ISO'
  - name: DIN SAE
    priority: 150
    pattern: '^DIN(?:\\s*|_|-)*SAE(?:\\s*SPEC)?'
    folder: 'DIN'
    original_abbrev: 'DIN SAE'

  # ISO IEC / ISO SAE / ISO
  - name: ISO IEC
    priority: 140
    pattern: '^ISO(?:\\s*|_|-)*IEC'
    folder: 'ISO'
    original_abbrev: 'ISO IEC'
  - name: ISO SAE (PAS)
    priority: 140
    pattern: '^ISO(?:\\s*|_|-)*SAE(?:\\s*PAS)?'
    folder: 'ISO'
    original_abbrev: 'ISO SAE'
 - name: ISO
    priority: 110
    # было: '^ISO\\s*\\d'
    # стало: допускаем ноль или более разделителей пробел|_|-|. перед цифрами
    pattern: '^ISO(?:\\s*|_|-|\\.)*\\d'
    folder: 'ISO'
    original_abbrev: 'ISO'

  # Общий BAC — в самом конце этой группы
  - name: BAC generic
    priority: 120
    pattern: '^BAC[\\s\\-A-Z0-9_]+'
    folder: 'BAC'
    original_abbrev: 'BAC'
"""

    def _load_yaml_rules(self, rules_file: Optional[str]):
        raw = self.DEFAULT_RULES_YAML
        if rules_file:
            try:
                with open(rules_file, 'r', encoding='utf-8') as f:
                    raw = f.read()
            except Exception:
                if self.logger:
                    self.logger.warning(f"Не удалось открыть rules.yaml: {rules_file}, используются дефолтные.")
        try:
            data = yaml.safe_load(raw) or {}
            self.detect_rules = data.get('detect', [])
            # сортировка по приоритету убыв.
            self.detect_rules.sort(key=lambda r: r.get('priority', 0), reverse=True)
        except Exception:
            self.detect_rules = []

    def apply_rules(self, filename: str) -> Optional[Tuple[str, str]]:
        name_up = filename.upper()
        for rule in self.detect_rules:
            pat = rule.get('pattern')
            if not pat:
                continue
            m = re.search(pat, filename, flags=re.IGNORECASE)
            if not m:
                continue

            folder: Optional[str] = rule.get('folder')
            original: Optional[str] = rule.get('original_abbrev')

            if rule.get('folder_from_group'):
                gi = int(rule['folder_from_group'])
                folder = m.group(gi).upper()

            if rule.get('original_abbrev_from_group'):
                gi = int(rule['original_abbrev_from_group'])
                original = m.group(gi)

            if not folder:
                continue
            if not original:
                original = folder

            # пост-валидация
            if self.is_valid_standard(filename, folder, original):
                return folder, original
        return None

    def is_valid_standard(self, filename: str, folder: str, original_abbrev: str) -> bool:
        """
        Лёгкая фильтрация «мусора» по семействам из комментариев коллег.
        """
        name_lower = filename.lower()
        folder_up = folder.upper()

        # Русские исключения
        if folder == 'ПИ' and any(w in name_lower for w in ['письмо', 'письма']):
            return False
        if folder == 'СП' and any(w in name_lower for w in ['список', 'справка']):
            return False

        # AMS — отсечь Airbus Illustrated Parts и AIPI/AIPC в AMS
        if folder_up == 'AMS':
            bad_tokens = ['illustrated', 'aipi', 'aipc']
            if any(t in name_lower for t in bad_tokens):
                return False

        # AN: после AN обязательно цифры
        if folder_up == 'AN':
            if not re.search(r'^(?i:AN)\s*\d', filename):
                return False

        # AS — только AS<цифры> или AS-<цифры>; отсекаем чертежи
        if folder_up == 'AS':
            if not re.match(r'^(?i:AS)\s*-?\d', filename):
                return False
            if 'dwg' in name_lower or 'drawing' in name_lower:
                return False

        # ASN — отсекаем явные нерелевантные
        if folder_up == 'ASN':
            if any(b in name_lower for b in ['wiring diagrams', 'entertainment']):
                return False

        # D8 — только D8-XXXX
        if folder_up == 'D8':
            if not re.match(r'^(?i:D8)-\w+', filename):
                return False

        # D6 — только D6-XXXX; не manual
        if folder_up == 'D6':
            if not re.match(r'^(?i:D6)-\w+', filename):
                return False
            if 'manual' in name_lower:
                return False

        # D2 — только D2-XXXX (отсекает Airbus D21570422_016 и т.п.)
        if folder_up == 'D2':
            if not re.match(r'^(?i:D2)-\w+', filename):
                return False

        # DIN — EN/ISO/SAE(SPEC) или DIN <номер>
        if folder_up == 'DIN':
            ok = (re.match(r'^(?i:DIN)\s+(EN|ISO|SAE)(?:\s+SPEC)?\s+\S', filename)
                  or re.match(r'^(?i:DIN)\s+\d', filename))
            if not ok:
                return False

        # ISO — допускаем 'ISO' без пробела, а также разделители '_', '-', '.'
        if folder_up == 'ISO':
            sep = r'(?:\s*|_|-|\.)*'  # ноль или более разделителей
            ok = (
                re.match(rf'^ISO{sep}\d', filename, re.IGNORECASE) or
                re.match(rf'^ISO{sep}IEC{sep}\S', filename, re.IGNORECASE) or
                re.match(rf'^ISO{sep}SAE(?:{sep}PAS)?{sep}\S', filename, re.IGNORECASE)
            )
            if not ok:
                return False


        # LN/MS/NAS/HST/MEP/NE/SPM/TAN — базовая проверка начала
        if folder_up in ('LN', 'MS', 'NAS', 'HST', 'MEP', 'NE', 'SPM', 'TAN'):
            if not re.match(rf'^(?i:{folder_up})\s*[\w-]', filename):
                return False

        return True
