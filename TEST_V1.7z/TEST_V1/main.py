"""
SpecSorter v8.1 - точка входа.
Запуск приложения, конфигурация логирования, обработка критических исключений.
"""

import sys
import json
import logging
from pathlib import Path
from tkinter import messagebox

from gui import Application
import tkinter as tk

DEFAULT_CONFIG = {
    "version": "8.1",
    "default_file_formats": "pdf, doc, docx, tif, tiff, dwg, xls, xlsx, gif, jpg, JPG",
    "catalog_filename": "specifications_catalog.xlsx",
    "unknown_folder": "_UNKNOWN",
    "corrupt_folder": "_CORRUPT",
    "office_temp_prefix": "~$",
    "max_retry_attempts": 3,
    "retry_delay_sec": 0.5,
    "gui_update_batch_size": 50,
    "default_max_workers": 4,
    "hash_mode": "full",  # "full" | "sampled" | "none"
}

def configure_root_logger():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)]
    )
    return logging.getLogger("SpecSorter")

def load_config(path: Path) -> dict:
    cfg = dict(DEFAULT_CONFIG)
    if path.exists():
        try:
            with path.open("r", encoding="utf-8") as f:
                data = json.load(f)
            cfg.update(data)
        except Exception:
            pass
    return cfg

def main():
    root_logger = configure_root_logger()
    config = load_config(Path("config.json"))

    try:
        root = tk.Tk()
        app = Application(master=root, app_logger=root_logger, app_config=config)
        def on_closing():
            if messagebox.askokcancel("Выход", "Вы уверены, что хотите выйти?"):
                root.destroy()
        root.protocol("WM_DELETE_WINDOW", on_closing)
        app.mainloop()
    except Exception:
        root_logger.critical("Не удалось запустить приложение.", exc_info=True)
        try:
            messagebox.showerror("Критическая ошибка", "Приложение не запустилось, см. логи в консоли.")
        except Exception:
            pass
        sys.exit(1)

if __name__ == "__main__":
    main()